Command to run the python file: python HW2.py Make sure this program file is in the same directory where the data folder containing train, dev and test is stored.

The training data file should be named as 'train'
The development data file should be named as 'dev'
The testing data file should be named as 'test'


Dependencies: Libraries used pandas and json.