Two files are given with this HW. HW4.py will generate the results on the trained model. But if you want to train the model. Run the train.ipynb

There is another folder named Model which has two trained model. First one blstm1.pt is for the task1 and second file blstm2.pt is for the task2.
Make sure to copy these folders in your current directory where HW4.py is stored.

Similarly to generate similar results load the same vocab dictionary, label dictionary and embedding matrix which is also provided with this model folder.
Vocab File: vocab.json
Label File: label.json
Embedding Matrix: emb_matrix.npy

Command to run the python file : python HW4.py

Note: all the above mentioned files should be in the same directory with data files(train, dev, test).