# CSCI544-NLP-HW
- HW1: Word embedding machine learning models for sentimental analysis reviews
- HW2: Word_embedding deep learning models semantic analysis reviews
- HW3: Language_model using greedy-viterbi decoding of HMM model
- HW4: BiLSTM_Vanilla Architecture for Named-Entity Recognition
