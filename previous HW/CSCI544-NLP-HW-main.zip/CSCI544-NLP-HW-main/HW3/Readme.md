Python Version: 3.8.8
Local System: Windows 10 64-bit machine 16GB Ram. AMD Ryzen 9 5900HX with Radeon Graphics 3.30 GHz

Command to run the python file: python HW3.py
Make sure this program file stored where the data folder is stored.

Libraries used pandas, numpy and json.

Time taken by Viterbi decoding for validation dataset is 11m 21s and for testing dataset is 